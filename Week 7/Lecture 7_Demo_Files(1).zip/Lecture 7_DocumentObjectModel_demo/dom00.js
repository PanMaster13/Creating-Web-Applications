// Part 1 - Place all the event functions here
function saveUserId () {
	/*
		Remember userId contains an object, to get the value of 
		of the userId, you must access the value method. For example
		
		userId.value <--- read as value of userId (remeber our right to left reading)
		
	*/

	var userId = document.getElementById("userId");

	// Using local storage
	localStorage.setItem("userId", userId.value);

	// Using cookies
	document.cookie = "userId=" + userId.value + ";";

}

// Part 2 - Link all HTML objects (elements) to their respective event function
function init () {
	var btnNext = document.getElementById("next");
	btnNext.onclick = saveUserId;
}
window.onload = init;