// Part 1 - Place all the event functions here
// Data Validation
function validateData() {
	var result = true;	// assign true if your data validation is looking for errors
	var res01 = document.getElementById("r01");
	var res02 = document.getElementById("r02");
	
	// For example, check if neither of the radio buttons were clicked
	if ((!res01.checked) && (!res02.checked)){
		alert ("Please select an answer.");
		result = false;
	}
	/*
		Remember to return 
		-	true if all form data are checked to be good
		- false if at least 1 of the data is invalid
	*/
	return result;
}

// Radio button interaction
function checkRadio () {
	var res01 = document.getElementById("r01");
	var res02 = document.getElementById("r02");
	var chk01 = document.getElementById("chk01");
	
	// Mark the question with a check [/] or [X]
	if (res01.checked) {
		chk01.textContent = "[/] ";
	} else if (res02.checked) {
		chk01.textContent = "[X] ";
	}

	// Prevent the user from changing the answer
	res01.disabled = true;
	res02.disabled = true;
}

// DOM - children versus childNodes
function demo01 () {
	// a collection is always expressed in plural form
	var elmtBody  = document.getElementsByTagName("body");
	alert ("Element Collection: " + elmtBody);
	alert ("First item in the collection: " + elmtBody[0]);
	alert ("id property of the first item: " + elmtBody[0].id);
	alert ("class property of the first item: " + elmtBody[0].className);  		// remember class is a keyword
	alert ("First child of the first item using childNodes: " + elmtBody[0].childNodes[0]); 	// Counts the carriage return
	alert ("First child of the first item using children: " + elmtBody[0].children[0]);		// ignores the carriage return
	
	// How about getting styles, unfortunately CSS can only be set (assigned) not get (read0
	alert ("Color of the first element (blank): " + elmtBody[0].style.color);		// will return an empty string
	
	// however you can change the color using
	elmtBody[0].style.color = "black";	// from blue it should now be black.
	
	// in case, we really like to read the property, 2 additional methods need to be used
	alert ("Color of the first element (working):" + getComputedStyle(elmtBody[0]).getPropertyValue("color"));
	
	// finally for CSS properties that contain dash(es) - like text-decoration
	// just remove all the dash(es) and use camel casing
	elmtBody[0].style.textDecoration = "underline";
	
	alert ("You should now have black and underlined text");
}

// Local Storage - Data Retrieval
function demo02 () {
	var userId = localStorage.getItem ("userId");
	alert ("User ID is  " + userId);
}

// Cookies  - Data Retrieval
function demo03 () {
	// Code directly lifted from the lecture notes
	// Get all the cookies pairs 
	var allCookies = document.cookie;
	// Split each pair as an element in an array
	cookieArray  = allCookies.split(';');
	// Access each pair as an element, remember to use var for i
	for (var i=0; i<cookieArray.length; i++){
		// split each element into name and value
		name = cookieArray[i].split('=')[0];
		value = cookieArray[i].split('=')[1];
		alert("Key is " + name + " and value is " + value);
	}
}


// Part 2 - Link all HTML objects (elements) to their respective event function
function init () {
	// Link the form's submit button, note that you use the form ID
	var btnSubmit = document.getElementById("f01");
	btnSubmit.onsubmit = validateData;

	// Link the two radio buttons for interactive data validation
	var res01 = document.getElementById("r01");
	var res02 = document.getElementById("r02");
	res01.onclick = checkRadio;
	res02.onclick = checkRadio;

	// Link the three demo  buttons
	var btnDemo01 = document.getElementById("demo01");
	var btnDemo02 = document.getElementById("demo02");
	var btnDemo03 = document.getElementById("demo03");
	btnDemo01.onclick = demo01;
	btnDemo02.onclick = demo02;
	btnDemo03.onclick = demo03;
}
window.onload = init;