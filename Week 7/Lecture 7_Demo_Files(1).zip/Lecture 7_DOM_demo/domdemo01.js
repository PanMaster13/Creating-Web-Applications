/* customised code - behaviour   */
function validate () {
	var result = true;
	var errmsg = "";

	/* assign the HTML element to a JavaScript variable   */
	var uname = document.getElementById ("uname");
	var uname_msg = document.getElementById ("uname_msg");
	
	/* Look for something wrong and assign false to variable result*/

	/* Save user name in local storage, if there are no errors */
	if (result) {
		localStorage.setItem("uname",uname.value);
	}
	
	/* go back to the calling program */
	return result;
}

function checkdata () {
	/* 	The keyword "this" refers to the object which fire (trigger) the 
			checkdata function (method). You can use if statement to check the
			"id" value and perform corresponding tests
	*/
	var actual_name = this.id;

	/* g stands for generic */
	var gname = document.getElementById (actual_name);
	var gname_msg = document.getElementById (actual_name + "_msg");
	
	/* Depending on your programming practice, you can group all the vars together
			or move the following line after if (actual_name == "rname") {
	*/
	var sname_blk = document.getElementById ("sname_blk");
	
	/* Performs a general validation of the textbox value */
	if (gname.value.length > 5) {
		gname_msg.textContent = "Good";
	} else {
		gname_msg.textContent = "At least 5 characters";
	}
	
	/* Performs test only if "rname" is edited */
	if (actual_name == "rname") {
		if (gname.value.length > 0) {
			sname_blk.style.display = "block";
			regForm.style.backgroundColor = "#cfcfcf";	// - is replaced with camel case
		} else {
			sname_blk.style.display = "none";
			regForm.style.backgroundColor = "#efefef";	// otherwise - is treated as minus
		}
	}
}

/* link customised functions to the HTML code  */
function init () {
	/* assign the HTML element to a JavaScript variable   */
	var regForm = document.getElementById ("regForm");
	var uname = document.getElementById ("uname");
	var rname = document.getElementById ("rname");
	var sname = document.getElementById ("sname");
	
	/* assign the code to the HTML element's event   */
	regForm.onsubmit = validate;
	uname.onblur = checkdata;
	rname.onblur = checkdata;
	sname.onblur = checkdata;
	/* Notes:
			onblur fires when the cursor leaves the text box
			onchange fires when the cursor leaves the text box and there 
							is a change in the value of the textbox
		 Remember without the () e.g. checkdata not checkdata(). The entire function
				is copied into the object's onblur event. Thus in the computer's memory
				there are 2 copies (instances) of checkdata. This relates to the 
				"this" keyword above.
	*/
	
	/* check if anything was previously saved */
	if (localStorage.getItem ("uname") != null) {
		/* retrieve any data that may have been previously saved  */
		uname.value = localStorage.getItem ("uname");
	}
	
	/* the following code dynamically creates the <span> element */

	/* creates a span element ALL CAPS please	*/
	var node = document.createElement("SPAN");	
	/* creates a text node, refer to the lecture slides, notice it used the broken 
		line for the box. This is because element are not the same as text content */
	var textnode = document.createTextNode("This is cool!"); 
	/* This appends the text to the element */
	node.appendChild(textnode);
	/* This sets the id attribute of the node */
	node.setAttribute ("id", "sname_msg");
	/* This appends the new span element to after the <input> element. 
	In case, you want specific position, try the insertBefore () method */
	document.getElementById("sname_blk").appendChild(node);
}

window.onload = init;
