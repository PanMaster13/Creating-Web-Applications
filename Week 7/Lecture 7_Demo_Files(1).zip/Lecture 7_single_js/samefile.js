// Place all customised functions
// - customised functions for Page 1

// - customised functions for Page 2

// - customised functions for Page 3


// Links html elements to customise JavaScript functions
function init () {

	// Get the value of the page id (not the meta element)
	var pageId = document.getElementById ("pageId").content;
	
	// Perform the respective initialisation based on which HTML loads the JavaScript file
	if (pageId == "Page 1") {
		// initialisation statements for Page 1
	}
	if (pageId == "Page 2") {
		// initialisation statements for Page 2
	}
	if (pageId == "Page 3") {
		// initialisation statements for Page 3
	}
}


window.onload = init;