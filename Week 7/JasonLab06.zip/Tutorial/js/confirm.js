/*  Filename: confirm.js
	Target html: confirm.html
	Author: Jason Ang Chia Wuen
	Date written: 19/4/2018 4:12pm
*/

var x = sessionStorage.firstname;
document.getElementById("confirm_name").textContent = x;

alert("It links");