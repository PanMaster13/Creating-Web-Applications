/*  Filename: navigation.js
	Target html: register.html
	Author: Jason Ang Chia Wuen
	Date written: 13/3/2018 2:10pm
*/

document.write('<header><img src="Images/logo.png" alt="Swinburne Logo"></header><nav><ul><li><a href="http://www.swinburne.edu.my/contact/">Contact Us</a>|</li><li><a href="http://www.swinburne.edu.my/hr/">Jobs at Swinburne</a>|</li><li><a href="http://www.swinburne.edu.au/copyright-disclaimer/">Copyright and disclaimer</a>|</li><li><a href="https://www.swinburne.edu.my/?p=1295">Privacy</a>|</li><li><a href="https://www.swinburne.edu.my/?p=1311">Accessibility</a>|</li><li><a href="https://www.swinburne.edu.my/?p=1318">Feedback</a></li><li><a href="register.html">Register</a></li></ul></nav>');