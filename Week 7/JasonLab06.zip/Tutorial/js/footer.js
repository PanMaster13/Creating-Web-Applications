/*  Filename: navigation.js
	Target html: register.html
	Author: Jason Ang Chia Wuen
	Date written: 13/4/2018 2:10pm
*/

document.write('<footer><p>Posted by: Jason Ang Chia Wuen</p><p>Contact information: <a href="mailto:r.mukuro00@hotmail.com">r.mukuro00@hotmail.com</a></p></footer>');

