<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>PHP and HTML elements</title>
</head>
<body>
<?php
	/*
		This section demonstrates how to use variable values a dynamically 
		complete  HTML elements using heading as example.
	*/
	echo "<h1>Example #3: PHP Dynamic HTML Element Completion Demo</h1>";
	for ($i = 1; $i < 7; $i++) {
		echo "<h$i>Heading $i</h$i>";
	}
	?>
</body>
</html>