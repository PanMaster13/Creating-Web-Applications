<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>My Website</title>
</head>
<body>
<?php
	define ("MAX_ELEMENT", 8);	// do not  forget the double quotes

	echo "<h1>Welcome to PHP - Constant and Loop Demonstration</h1>"; 
	echo "<ol>";
	// all variables a local by default unlike JavaScript
	for ($i = 0; $i < MAX_ELEMENT; $i++) {
		echo "<li>item ",($i+1), " </li>";
	}
	echo "</ol>";
?>
</body>
</html>