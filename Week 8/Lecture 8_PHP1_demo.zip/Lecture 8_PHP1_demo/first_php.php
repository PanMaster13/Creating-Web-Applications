<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>My Website</title>
</head>
<body>
<p>Hello World in unprocessed HTML</p>
<?php
	echo "<p>Hello World in HTML created by PHP</p>";
	
	echo "test";
?>
</body>
</html>

