<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>PHP and HTML interleaving</title>
</head>
<body>
<?php
	echo "<h1>Example #1: PHP Sectioning Demo</h1>";
	for ($i = 1; $i < 7; $i++) {
		echo "<h$i>"?>Heading 
		<?php echo "$i</h$i>";
	}
	?>
</body>
</html>