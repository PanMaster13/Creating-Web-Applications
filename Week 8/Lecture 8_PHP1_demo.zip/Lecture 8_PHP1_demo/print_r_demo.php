<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>My Website</title>
</head>
<body>
<?php
	// arrays can be created together with the elements
	$firstNames = array ("Adam", "Alice", "Ben", "Barbara",
										"Chris", "Charlie", "Dean", "Dave");
	// elements can be added dynamically even after the array had been created
	$firstNames[] = "Eric";
	$firstNames[] = "Erica";
	$firstNames[] = "Gary";
	$firstNames[] = "Gerry";
	
	echo "<h1>Welcome to PHP - Array Demonstration!</h1>"; 
	echo "<ol>";
	for ($i = 0; $i < count ($firstNames); $i++) {
		echo "<li>Name $firstNames[$i]</li>";
	}
	echo "</ol>";

	// use print_r for debugging purposes only
	print_r ($firstNames);
?>
</body>
</html>