/* Filename: lect5_html_io.js
   Purpose : demonstrate javascript alerts  
   Target html: lect5_html_io.htm
   Author: A Lecturer
   Date written: 21 Jan 2017   
*/
/* getInputInfo retrieves text from the HTML text box then calls displayAlert */
//"use strict";

function getInputInfo()
{
  	var myString;      //declare local variables 
	myString = prompt("Enter the string", "The string");
	alert("Your output: " + myString);
	//the next line should have a var declaration - will throw an error the "use strict" declared 
	outputMessage = document.getElementById("mymessage"); //placeholder for display text
	outputMessage.textContent="Your output: " + myString; //write string to html page
}

function init() {
	var clickme = document.getElementById("clickme");     //object in HTML
	clickme.onclick = getInputInfo;          
	}

window.onload = init;      //note: no brackets after function name.

