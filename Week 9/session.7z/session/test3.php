﻿
<form method="post" action="page2.php">
	<label for="fName">First Name: </label>
	<input type="text" name="fName"/>
	<input type="hidden" name="secret" value="XXX" />
	<input type="submit" name="Submit" value="Submit" />
</form>


