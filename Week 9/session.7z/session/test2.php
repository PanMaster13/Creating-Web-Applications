﻿<?php
	session_set_cookie_params(3600);
	session_start();
   
	$_SESSION['firstName']="John";
	$_SESSION['lastName']="Smith";
?>

<p><a href='<?php echo "Occupation.php?" . session_id()?>'>Occupation</a></p>