<?php
		
	if (isset($_POST['fName']) && isset($_POST['secret']))
	{
		echo "<p>" . $_POST['fName'] . " " . $_POST['secret'];		
		
	}
?>