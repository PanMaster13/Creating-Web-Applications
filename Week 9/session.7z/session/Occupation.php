<?php
	session_start();
	
	if (isset($_SESSION['firstName']) && isset($_SESSION['lastName']))
	{
		echo "<p>" . $_SESSION['firstName'] . " " . $_SESSION['lastName'];		
		
	}
?>