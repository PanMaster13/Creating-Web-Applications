<!DOCTYPE html>
<html>
 <head>
	<meta charset="utf-8">
	<title>COS10011 Creating Web Applications</title>

 </head>
 <body>

<!--   page content -->
<h1>Second Page</h1>

<?php
session_start();

$_SESSION['firstname']; 
$_SESSION['lastname'];

echo "<h2>We pass the session value from previous PHP page.</h2>";
echo "<p>Firstname:".$_SESSION['firstname']."</p>";
echo "<p>Lastname:".$_SESSION['lastname']."</p>";
?>



 </body>
</html>