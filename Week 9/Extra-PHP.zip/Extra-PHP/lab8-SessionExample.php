<!DOCTYPE html>
<html>
 <head>
	<meta charset="utf-8">
	<title>COS10011 Creating Web Applications</title>

 </head>
 <body>


<!--   page content -->
<h1>Example using SESSION function</h1>
<form method="post" action="secondPage.php">
<?php
session_start();

$_SESSION['firstname'] = "john";
$_SESSION['lastname'] = "mike";

echo "<h2>Assume we have to value store in firstname and lastname</h2>";
echo "<p>Firstname:".$_SESSION['firstname']."</p>";
echo "<p>Lastname:".$_SESSION['lastname']."</p>";

?>
<input type="submit" name="submit" value="submit">
</form>


 </body>
</html>